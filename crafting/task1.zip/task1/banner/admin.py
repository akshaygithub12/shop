from django.contrib import admin
from .models import Menu1
# Register your models here.
admin.site.register(Menu1)